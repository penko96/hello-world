import java.util.Scanner;

public class Calculate_Expression {
    public static void main(String[] args) {

        double a,b,c;
        double fa,fb,fc,fd;
        double f1,f2,f3,f4;
        double f1result, f2result, f3result;

        Scanner numbers =  new Scanner(System.in);
        a=numbers.nextDouble();
        b=numbers.nextDouble();
        c=numbers.nextDouble();

       // System.out.println(a+b+c);

        f1 = (a*a+b*b)/(a*a-b*b);
        f2 =(a*a+b*b-c*c*c);

        fa = (a+b+c)/Math.sqrt(c);
        fb = a-b;

        f1result = Math.pow(f1,fa);
        f2result = Math.pow(f2,fb);
        f3result = Math.abs(((a+b+c)/3) - ((f1result+f2result)/2));

        System.out.printf("F1 result: %.2f; F2 result: %.2f; Diff: %.2f",f1result,f2result,f3result);


    }
}
