import java.util.Scanner;

public class Rectangle_Area {
    public static void main(String[] args) {

        System.out.print("a= ");
        Scanner sidea = new Scanner(System.in);
        int sideA = sidea.nextInt();

        System.out.print("b= ");
        Scanner sideb = new Scanner(System.in);
        int sideB = sideb.nextInt();

        System.out.print(sideA*sideB);





    }
}
