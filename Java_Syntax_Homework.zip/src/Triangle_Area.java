import java.util.Scanner;

public class Triangle_Area {
    public static void main(String[] args) {

        System.out.println("vyvedete kordinati za t.A:");
        Scanner cordinatesToA = new Scanner(System.in);
        int xa = cordinatesToA.nextInt();
        int ya = cordinatesToA.nextInt();

        System.out.println("vyvedete kordinati za t.B:");
        Scanner cordinatesToB = new Scanner(System.in);
        int xb = cordinatesToB.nextInt();
        int yb = cordinatesToB.nextInt();

        System.out.println("vyvedete kordinati za t.C:");
        Scanner cordinatesToC = new Scanner(System.in);
        int xc = cordinatesToC.nextInt();
        int yc = cordinatesToC.nextInt();

        long a = 0;
        long b = 0;
        long c = 0;

        a = Math.round(Math.sqrt(Math.pow((xb - xa), 2) + Math.pow((yb - ya), 2)));
        b = Math.round(Math.sqrt(Math.pow((xc - xb), 2) + Math.pow((yc - yb), 2)));
        c = Math.round(Math.sqrt(Math.pow((xa - xc), 2) + Math.pow((ya - yc), 2)));

        if (a>b+c || b>a+c || c>a+b ) {
            System.out.print("0");
        }else {


            System.out.println("a=" + a);
            System.out.println("b=" + b);
            System.out.println("c=" + c);

            long p = Math.round(a + b + c) / 2;
            System.out.println("p=" + p);

            long area = Math.round(Math.sqrt(p * (p - a) * (p - b) * (p - c)));

            System.out.println("The Area Is: " + area);
        }
    }
}
